import {
  useEffect,
  useRef,
  type CSSProperties,
  type ElementType,
  type ReactNode,
} from "react";
import { cn } from "./utils/cn";

type Category = {
  title: string;
  subtitle: string;
  image: string;
  highlighted?: boolean;
};

type Promo = {
  tone: "olive" | "copper" | "charcoal";
  title: string;
  price: string;
  image: string;
  reveal: "fade-right" | "fade-up" | "fade-left";
};

type Dish = {
  badge: string;
  title: string;
  description: string;
  price: string;
  rating: string;
  image: string;
  tilt?: boolean;
};

const images = {
  heroBurger:
    "https://images.pexels.com/photos/4628466/pexels-photo-4628466.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=1000",
  burgerAlt:
    "https://images.pexels.com/photos/1639562/pexels-photo-1639562.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=1000",
  burgerCard:
    "https://images.pexels.com/photos/11022623/pexels-photo-11022623.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=1000",
  hotDog:
    "https://images.pexels.com/photos/37098335/pexels-photo-37098335.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900",
  chicken:
    "https://images.pexels.com/photos/38549533/pexels-photo-38549533.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=1000",
  biryani:
    "https://images.pexels.com/photos/17696653/pexels-photo-17696653.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900",
  fries:
    "https://images.pexels.com/photos/29285460/pexels-photo-29285460.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900",
  pizza:
    "https://images.pexels.com/photos/30301971/pexels-photo-30301971.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900",
  quesadilla:
    "https://images.pexels.com/photos/32351726/pexels-photo-32351726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=1600",
  drink:
    "https://images.pexels.com/photos/37925075/pexels-photo-37925075.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
};

const navItems = [
  { label: "Home", href: "#home" },
  { label: "Menu", href: "#menu" },
  { label: "Pages", href: "#about" },
  { label: "Shop", href: "#popular" },
  { label: "Blog", href: "#offers" },
  { label: "Contact", href: "#contact" },
];

const categories: Category[] = [
  {
    title: "Hot Dogs",
    subtitle: "A proper classic",
    image: images.hotDog,
  },
  {
    title: "Burgers",
    subtitle: "Flame-grilled goodness",
    image: images.burgerAlt,
  },
  {
    title: "Crispy Chicken",
    subtitle: "Crunch into crispiness",
    image: images.chicken,
    highlighted: true,
  },
  {
    title: "Biryani",
    subtitle: "A bowl full of flavor",
    image: images.biryani,
  },
  {
    title: "Loaded Fries",
    subtitle: "Go all in",
    image: images.fries,
  },
  {
    title: "Pizza",
    subtitle: "Love at first slice",
    image: images.pizza,
  },
];

const promos: Promo[] = [
  {
    tone: "olive",
    title: "Crispy Chicken Meals",
    price: "$10.99",
    image: images.chicken,
    reveal: "fade-right",
  },
  {
    tone: "copper",
    title: "Big Bold Beef Burger",
    price: "$12.99",
    image: images.burgerCard,
    reveal: "fade-up",
  },
  {
    tone: "charcoal",
    title: "Cheesy. Crispy. Pizza.",
    price: "$16.99",
    image: images.pizza,
    reveal: "fade-left",
  },
];

const dishes: Dish[] = [
  {
    badge: "Bestseller",
    title: "Double Beef Burger",
    description:
      "Two juicy patties, American cheese, cheddar, crisp lettuce and our signature sauce.",
    price: "$12.99",
    rating: "4.8 (124)",
    image: images.burgerAlt,
    tilt: true,
  },
  {
    badge: "Stone Baked",
    title: "Pepperoni Cheese Pizza",
    description:
      "Savory, stretchy cheese, rich tomato sauce, stretchy mozzarella and bold pepperoni.",
    price: "$16.99",
    rating: "4.8 (98)",
    image: images.pizza,
  },
  {
    badge: "Fan Favorite",
    title: "Crispy Fried Chicken",
    description:
      "Golden, crunchy chicken with real bold eleven-spice seasoning and a hot finish.",
    price: "$10.99",
    rating: "4.9 (109)",
    image: images.chicken,
  },
  {
    badge: "Chef Pick",
    title: "Signature Chicken Biryani",
    description:
      "Fragrant basmati rice, slow-cooked chicken and warming aromatic spices in every bowl.",
    price: "$13.99",
    rating: "4.8 (88)",
    image: images.biryani,
    tilt: true,
  },
];

const footerLinks = [
  { label: "Home", href: "#home" },
  { label: "Menu", href: "#menu" },
  { label: "Shop", href: "#popular" },
  { label: "Blog", href: "#offers" },
  { label: "Contact", href: "#contact" },
];

function motionStyle(delay = 0, duration = 760): CSSProperties {
  return {
    ["--delay" as string]: `${delay}ms`,
    ["--duration" as string]: `${duration}ms`,
  } as CSSProperties;
}

function useScrollAnimationSystem() {
  useEffect(() => {
    if (typeof window === "undefined" || !("IntersectionObserver" in window)) {
      return;
    }

    const root = document.documentElement;
    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (prefersReducedMotion) {
      delete root.dataset.motionReady;
      return;
    }

    const revealItems = Array.from(
      document.querySelectorAll<HTMLElement>("[data-reveal]"),
    );

    if (!revealItems.length) {
      return;
    }

    const markWithinActivationArea = () => {
      const viewportHeight = window.innerHeight;
      revealItems.forEach((item) => {
        const rect = item.getBoundingClientRect();
        const active = rect.top <= viewportHeight * 0.9 && rect.bottom >= -viewportHeight * 0.12;
        item.dataset.inview = active ? "true" : "false";
      });
    };

    const observer = new IntersectionObserver(
      (entries) => {
        const viewportHeight = window.innerHeight;

        entries.forEach((entry) => {
          const target = entry.target as HTMLElement;
          const rect = entry.boundingClientRect;
          const inActivationZone = rect.top <= viewportHeight * 0.9 && rect.bottom >= -viewportHeight * 0.12;

          if (entry.isIntersecting || entry.intersectionRatio > 0.02 || inActivationZone) {
            target.dataset.inview = "true";
          } else {
            target.dataset.inview = "false";
          }
        });
      },
      {
        root: null,
        rootMargin: "14% 0px -10% 0px",
        threshold: [0, 0.12, 0.3, 0.5],
      },
    );

    revealItems.forEach((item) => observer.observe(item));
    markWithinActivationArea();
    root.dataset.motionReady = "true";

    const handleResize = () => {
      markWithinActivationArea();
    };

    window.addEventListener("resize", handleResize, { passive: true });

    return () => {
      observer.disconnect();
      window.removeEventListener("resize", handleResize);
      delete root.dataset.motionReady;
      revealItems.forEach((item) => {
        delete item.dataset.inview;
      });
    };
  }, []);
}

function useTiltEffect<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);

  useEffect(() => {
    const element = ref.current;

    if (!element || typeof window === "undefined") {
      return;
    }

    const canHover = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (!canHover || prefersReducedMotion) {
      return;
    }

    let frame = 0;
    const current = { rx: 0, ry: 0, scale: 1, lift: 0 };
    const target = { rx: 0, ry: 0, scale: 1, lift: 0 };

    const render = () => {
      current.rx += (target.rx - current.rx) * 0.14;
      current.ry += (target.ry - current.ry) * 0.14;
      current.scale += (target.scale - current.scale) * 0.14;
      current.lift += (target.lift - current.lift) * 0.14;

      element.style.setProperty("--tilt-rx", `${current.rx.toFixed(2)}deg`);
      element.style.setProperty("--tilt-ry", `${current.ry.toFixed(2)}deg`);
      element.style.setProperty("--tilt-scale", current.scale.toFixed(3));
      element.style.setProperty("--tilt-lift", current.lift.toFixed(3));

      const stillMoving =
        Math.abs(target.rx - current.rx) > 0.02 ||
        Math.abs(target.ry - current.ry) > 0.02 ||
        Math.abs(target.scale - current.scale) > 0.002 ||
        Math.abs(target.lift - current.lift) > 0.002;

      if (stillMoving) {
        frame = window.requestAnimationFrame(render);
      } else {
        frame = 0;
      }
    };

    const queueFrame = () => {
      if (!frame) {
        frame = window.requestAnimationFrame(render);
      }
    };

    const resetTilt = () => {
      target.rx = 0;
      target.ry = 0;
      target.scale = 1;
      target.lift = 0;
      element.dataset.tiltHover = "false";
      queueFrame();
    };

    const handlePointerEnter = () => {
      element.dataset.tiltHover = "true";
      queueFrame();
    };

    const handlePointerMove = (event: PointerEvent) => {
      const rect = element.getBoundingClientRect();
      const px = (event.clientX - rect.left) / rect.width;
      const py = (event.clientY - rect.top) / rect.height;
      const dx = px - 0.5;
      const dy = py - 0.5;

      target.rx = dy * -7.5;
      target.ry = dx * 8.5;
      target.scale = 1.01;
      target.lift = Math.min(1, Math.abs(dx) + Math.abs(dy)) * 1.2;

      element.style.setProperty("--pointer-x", `${(px * 100).toFixed(2)}%`);
      element.style.setProperty("--pointer-y", `${(py * 100).toFixed(2)}%`);
      queueFrame();
    };

    const handlePointerDown = () => {
      target.scale = 0.995;
      queueFrame();
    };

    const handlePointerUp = () => {
      target.scale = 1.01;
      queueFrame();
    };

    element.addEventListener("pointerenter", handlePointerEnter);
    element.addEventListener("pointermove", handlePointerMove);
    element.addEventListener("pointerleave", resetTilt);
    element.addEventListener("pointercancel", resetTilt);
    element.addEventListener("pointerdown", handlePointerDown);
    element.addEventListener("pointerup", handlePointerUp);

    return () => {
      if (frame) {
        window.cancelAnimationFrame(frame);
      }
      element.removeEventListener("pointerenter", handlePointerEnter);
      element.removeEventListener("pointermove", handlePointerMove);
      element.removeEventListener("pointerleave", resetTilt);
      element.removeEventListener("pointercancel", resetTilt);
      element.removeEventListener("pointerdown", handlePointerDown);
      element.removeEventListener("pointerup", handlePointerUp);
    };
  }, []);

  return ref;
}

function SplitReveal({
  as: Tag = "span",
  text,
  className,
  delay = 0,
}: {
  as?: ElementType;
  text: string;
  className?: string;
  delay?: number;
}) {
  const letters = Array.from(text);

  return (
    <Tag
      aria-label={text}
      className={cn("split-reveal", className)}
      data-reveal="char"
      style={motionStyle(delay, 520)}
    >
      <span aria-hidden="true" className="split-reveal-track">
        {letters.map((letter, index) => (
          <span
            key={`${letter}-${index}`}
            className="split-reveal-char"
            data-char
            style={{ ["--char-index" as string]: index } as CSSProperties}
          >
            {letter === " " ? "\u00A0" : letter}
          </span>
        ))}
      </span>
    </Tag>
  );
}

function TiltFrame({ children, className }: { children: ReactNode; className?: string }) {
  const ref = useTiltEffect<HTMLDivElement>();

  return (
    <div className={cn("tilt-root", className)} data-tilt ref={ref}>
      <div className="tilt-surface">{children}</div>
    </div>
  );
}

function ActionButton({
  href,
  variant = "solid",
  className,
  children,
}: {
  href: string;
  variant?: "solid" | "light" | "ghost";
  className?: string;
  children: ReactNode;
}) {
  return (
    <a
      className={cn(
        "action-btn",
        variant === "solid" && "action-btn--solid",
        variant === "light" && "action-btn--light",
        variant === "ghost" && "action-btn--ghost",
        className,
      )}
      href={href}
    >
      <span>{children}</span>
      <ArrowUpRightIcon className="h-3.5 w-3.5" />
    </a>
  );
}

function App() {
  useScrollAnimationSystem();

  return (
    <div className="min-h-screen bg-[var(--cream)] text-[var(--ink)]">
      <div className="border-b border-white/10 bg-[var(--ink-deep)] text-[11px] uppercase tracking-[0.22em] text-white/85">
        <div className="mx-auto flex w-full max-w-[1240px] flex-col items-center justify-between gap-2 px-4 py-3 text-center sm:flex-row sm:px-6 lg:px-8">
          <p>Freshly made. Full of flavor.</p>
          <p>Free delivery on orders over $35 &nbsp; / &nbsp; Use FLAME10 for 10% off</p>
          <a className="transition-colors hover:text-[var(--gold)]" href="#contact">
            Find us
          </a>
        </div>
      </div>

      <header className="border-b border-[rgba(35,26,20,0.08)] bg-white/95 backdrop-blur-sm">
        <div className="mx-auto flex w-full max-w-[1240px] flex-col gap-5 px-4 py-5 sm:px-6 lg:px-8 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex items-center justify-between gap-4">
            <a className="inline-flex items-center gap-3" href="#home">
              <LogoMark />
              <div>
                <div className="font-display text-[2rem] uppercase leading-none tracking-[0.04em] text-[var(--brand-red)]">
                  Flame &amp; Bun
                </div>
              </div>
            </a>

            <div className="flex items-center gap-2 xl:hidden">
              <IconButton ariaLabel="Search">
                <SearchIcon className="h-4.5 w-4.5" />
              </IconButton>
              <IconButton ariaLabel="Cart">
                <div className="relative">
                  <CartIcon className="h-4.5 w-4.5" />
                  <span className="absolute -right-2 -top-2 inline-flex h-4 w-4 items-center justify-center rounded-full bg-[var(--brand-green)] text-[9px] font-bold text-white">
                    0
                  </span>
                </div>
              </IconButton>
            </div>
          </div>

          <nav className="overflow-x-auto pb-1 xl:pb-0">
            <ul className="flex min-w-max items-center gap-5 pr-2 text-[12px] font-extrabold uppercase tracking-[0.18em] text-[var(--ink)] xl:justify-center xl:gap-8">
              {navItems.map((item, index) => (
                <li key={item.label}>
                  <a
                    className={cn(
                      "group relative inline-flex py-1 transition-colors duration-300 hover:text-[var(--brand-red)]",
                      index === 0 && "text-[var(--brand-red)]",
                    )}
                    href={item.href}
                  >
                    {item.label}
                    <span
                      className={cn(
                        "absolute inset-x-0 -bottom-1 h-[2px] origin-left scale-x-0 bg-[var(--brand-red)] transition-transform duration-300 group-hover:scale-x-100",
                        index === 0 && "scale-x-100",
                      )}
                    />
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="hidden items-center gap-3 xl:flex">
            <IconButton ariaLabel="Search">
              <SearchIcon className="h-4.5 w-4.5" />
            </IconButton>
            <IconButton ariaLabel="Cart">
              <div className="relative">
                <CartIcon className="h-4.5 w-4.5" />
                <span className="absolute -right-2 -top-2 inline-flex h-4 w-4 items-center justify-center rounded-full bg-[var(--brand-green)] text-[9px] font-bold text-white">
                  0
                </span>
              </div>
            </IconButton>
            <ActionButton className="ml-1" href="#popular">
              Order now
            </ActionButton>
          </div>
        </div>
      </header>

      <main>
        <section className="mx-auto w-full max-w-[1240px] px-4 pt-5 sm:px-6 lg:px-8" id="home">
          <div className="hero-panel relative overflow-hidden rounded-[34px]">
            <div className="grid min-h-[640px] items-center gap-4 lg:grid-cols-[1.02fr_0.98fr]">
              <div className="relative z-10 px-6 pb-10 pt-10 text-white sm:px-8 lg:px-12 lg:pb-12 lg:pt-14 xl:px-14">
                <p
                  className="max-w-max rounded-full border border-white/15 bg-white/5 px-3 py-2 text-[10px] font-bold uppercase tracking-[0.35em] text-[var(--gold-soft)]"
                  data-reveal="fade-up"
                  style={motionStyle(0)}
                >
                  Fresh off the grill. Straight to the soul.
                </p>

                <SplitReveal
                  className="mt-7 block font-script text-[3rem] leading-none text-[var(--gold)] sm:text-[3.8rem]"
                  delay={80}
                  text="Premium"
                />

                <h1 className="mt-3 font-display text-[clamp(4rem,10vw,7.35rem)] uppercase leading-[0.82] tracking-[0.02em] text-white">
                  <span className="block overflow-hidden">
                    <span className="block" data-reveal="mask-up" style={motionStyle(120)}>
                      Grilled
                    </span>
                  </span>
                  <span className="mt-1 block overflow-hidden">
                    <span className="block" data-reveal="mask-up" style={motionStyle(220)}>
                      Beef Burger
                    </span>
                  </span>
                </h1>

                <p
                  className="mt-7 max-w-[32rem] text-base leading-8 text-white/80 sm:text-[1.02rem]"
                  data-reveal="fade-up"
                  style={motionStyle(260)}
                >
                  Two juicy patties. Melted cheese. Signature sauce. Some cravings deserve
                  the real thing.
                </p>

                <div data-reveal="scale-blur" style={motionStyle(340)}>
                  <ActionButton className="mt-9" href="#popular">
                    Order now
                  </ActionButton>
                </div>

                <div
                  className="mt-9 flex flex-wrap items-center gap-3 text-sm text-white/78"
                  data-reveal="fade-up"
                  style={motionStyle(400)}
                >
                  <div className="flex items-center gap-1 text-[var(--gold)]">
                    {Array.from({ length: 5 }).map((_, index) => (
                      <span key={index} className="rating-dot" />
                    ))}
                  </div>
                  <span>Made fresh. Loved by food lovers.</span>
                </div>

                <div
                  className="mt-8 flex flex-wrap gap-3"
                  data-reveal="fade-up"
                  style={motionStyle(460)}
                >
                  {[
                    "Fire-grilled daily",
                    "Never a boring bite",
                    "Made with flavor",
                  ].map((item) => (
                    <span className="hero-chip" key={item}>
                      {item}
                    </span>
                  ))}
                </div>
              </div>

              <div className="relative z-10 flex min-h-[430px] items-end justify-center px-6 pb-8 pt-6 lg:min-h-[640px] lg:px-10 lg:pb-0">
                <div
                  className="absolute right-7 top-7 z-20 grid h-28 w-28 place-items-center rounded-full border-[5px] border-[#b07f22] bg-[rgba(74,44,8,0.82)] shadow-[0_18px_40px_rgba(0,0,0,0.25)] sm:h-32 sm:w-32"
                  data-reveal="pop"
                  style={motionStyle(220, 720)}
                >
                  <div className="text-center text-[var(--gold)]">
                    <div className="font-display text-[1.2rem] uppercase tracking-[0.12em]">
                      $12
                    </div>
                    <div className="-mt-1 font-display text-[3rem] leading-none">.99</div>
                  </div>
                </div>

                <div className="relative w-full max-w-[620px]" data-reveal="scale-blur" style={motionStyle(180, 920)}>
                  <TiltFrame>
                    <div className="relative overflow-hidden rounded-[38px]">
                      <img
                        alt="Premium grilled beef burger stacked high with melted cheese"
                        className="hero-burger-image w-full object-cover object-center drop-shadow-[0_34px_50px_rgba(0,0,0,0.42)]"
                        decoding="async"
                        fetchPriority="high"
                        loading="eager"
                        src={images.heroBurger}
                      />
                    </div>
                  </TiltFrame>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[1240px] px-4 sm:px-6 lg:px-8" id="menu">
          <div className="grid grid-cols-2 overflow-hidden border border-[rgba(35,26,20,0.08)] bg-white md:grid-cols-3 xl:grid-cols-6">
            {categories.map((category, index) => (
              <article
                className={cn(
                  "category-card group border-b border-r border-[rgba(35,26,20,0.08)] px-4 py-6 text-center transition-colors duration-300 md:px-5",
                  category.highlighted && "is-highlighted",
                )}
                data-reveal={index % 2 === 0 ? "fade-up" : "lift"}
                key={category.title}
                style={motionStyle(60 + index * 70, 680)}
              >
                <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.98),rgba(250,244,235,0.84))] shadow-[0_10px_22px_rgba(96,68,42,0.12)]">
                  <img
                    alt={category.title}
                    className="h-16 w-16 rounded-full object-cover"
                    decoding="async"
                    loading={index < 2 ? "eager" : "lazy"}
                    src={category.image}
                  />
                </div>
                <h3 className="mt-5 font-display text-[2.05rem] uppercase leading-none tracking-[0.03em] text-[var(--ink)]">
                  {category.title}
                </h3>
                <p className="mt-2 text-sm text-[var(--ink-muted)]">{category.subtitle}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="mx-auto w-full max-w-[1240px] px-4 py-18 sm:px-6 lg:px-8 lg:py-24" id="about">
          <div className="grid items-center gap-12 lg:grid-cols-[0.9fr_1.1fr] xl:gap-18">
            <div className="relative">
              <div className="pointer-events-none absolute left-0 top-4 font-display text-[clamp(5rem,14vw,11rem)] uppercase leading-none tracking-[0.08em] text-[rgba(50,38,28,0.04)]">
                Flavor
              </div>

              <div className="relative pt-16" data-reveal="fade-right" style={motionStyle(80, 860)}>
                <TiltFrame className="mx-auto max-w-[540px]">
                  <div className="relative overflow-hidden rounded-[34px] bg-[radial-gradient(circle_at_35%_30%,rgba(255,255,255,0.8),rgba(247,237,223,0.95))] p-6 sm:p-8">
                    <div className="absolute inset-x-[14%] bottom-5 h-8 rounded-full bg-black/10 blur-2xl" />
                    <img
                      alt="Double beef burger prepared with fresh toppings"
                      className="relative z-10 mx-auto aspect-[1/1] w-full rounded-[28px] object-cover"
                      decoding="async"
                      loading="eager"
                      src={images.burgerCard}
                    />
                    <div className="absolute bottom-6 right-4 rounded-full border-[5px] border-white bg-[var(--brand-green)] px-5 py-5 text-center text-white shadow-[0_18px_40px_rgba(39,109,76,0.25)] sm:bottom-8 sm:right-6">
                      <div className="font-display text-[2.4rem] leading-none">100%</div>
                      <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-white/80">
                        juicy burger
                      </div>
                    </div>
                  </div>
                </TiltFrame>
              </div>
            </div>

            <div>
              <p
                className="text-[11px] font-extrabold uppercase tracking-[0.35em] text-[var(--brand-red)]/70"
                data-reveal="fade-up"
                style={motionStyle(0)}
              >
                About our food
              </p>

              <h2
                className="mt-4 max-w-[12ch] font-display text-[clamp(3.2rem,8vw,5.5rem)] uppercase leading-[0.9] tracking-[0.02em] text-[var(--ink)]"
                data-reveal="fade-up"
                style={motionStyle(120, 820)}
              >
                We make the best burger in your town.
              </h2>

              <p
                className="mt-6 max-w-[34rem] text-[1.02rem] leading-8 text-[var(--ink-muted)]"
                data-reveal="fade-up"
                style={motionStyle(210, 780)}
              >
                Big flavor starts with the little things. Fresh ingredients, a seriously hot
                grill, and a whole lot of love. Every burger is made to order. Every bite is
                worth coming back for.
              </p>

              <div className="mt-10 grid gap-5 md:grid-cols-3">
                {[
                  {
                    title: "Always Fresh",
                    body: "Real ingredients. Real good food.",
                    icon: <LeafSparkIcon className="h-5 w-5" />,
                  },
                  {
                    title: "Fire-Grilled",
                    body: "Seared to perfection. Packed with flavor.",
                    icon: <FlameIcon className="h-5 w-5" />,
                  },
                  {
                    title: "Fast Delivery",
                    body: "Fresh out of the kitchen to your doorstep.",
                    icon: <ScooterIcon className="h-5 w-5" />,
                  },
                ].map((feature, index) => (
                  <div
                    className="rounded-[24px] border border-[rgba(35,26,20,0.08)] bg-white/70 p-5 shadow-[0_18px_36px_rgba(93,72,43,0.06)]"
                    data-reveal="lift"
                    key={feature.title}
                    style={motionStyle(290 + index * 80, 680)}
                  >
                    <div className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-[rgba(196,82,56,0.08)] text-[var(--brand-red)]">
                      {feature.icon}
                    </div>
                    <h3 className="mt-4 font-display text-[1.85rem] uppercase leading-none tracking-[0.02em] text-[var(--ink)]">
                      {feature.title}
                    </h3>
                    <p className="mt-3 text-sm leading-7 text-[var(--ink-muted)]">{feature.body}</p>
                  </div>
                ))}
              </div>

              <div data-reveal="fade-up" style={motionStyle(520, 740)}>
                <ActionButton className="mt-8" href="#popular" variant="ghost">
                  A little more about us
                </ActionButton>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[1240px] px-4 sm:px-6 lg:px-8" id="offers">
          <div className="grid gap-[1px] overflow-hidden bg-[rgba(35,26,20,0.08)] lg:grid-cols-3">
            {promos.map((promo, index) => (
              <article
                className={cn(
                  "promo-card relative isolate min-h-[255px] overflow-hidden px-6 py-7 sm:px-7 sm:py-8",
                  promo.tone,
                )}
                data-reveal={promo.reveal}
                key={promo.title}
                style={motionStyle(60 + index * 100, 820)}
              >
                <div className="relative z-10 max-w-[13rem]">
                  <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/68">
                    A little craving. A lot of flavor.
                  </p>
                  <h3 className="mt-5 font-display text-[clamp(3rem,7vw,4.5rem)] uppercase leading-[0.87] tracking-[0.02em] text-white">
                    {promo.title}
                  </h3>
                  <p className="mt-3 font-display text-[2rem] uppercase tracking-[0.04em] text-[var(--gold)]">
                    {promo.price}
                  </p>
                  <ActionButton className="mt-6" href="#popular" variant="light">
                    Order now
                  </ActionButton>
                </div>

                <div className="absolute -bottom-10 right-[-3.5rem] z-0 h-48 w-48 rounded-full bg-white/88 sm:h-56 sm:w-56" />
                <img
                  alt={promo.title}
                  className="absolute bottom-0 right-[-1rem] z-10 h-44 w-44 rounded-full object-cover shadow-[0_18px_42px_rgba(0,0,0,0.2)] sm:h-52 sm:w-52"
                  decoding="async"
                  loading="lazy"
                  src={promo.image}
                />
              </article>
            ))}
          </div>
        </section>

        <section className="relative mx-auto w-full max-w-[1240px] overflow-hidden px-4 py-18 sm:px-6 lg:px-8 lg:py-24" id="popular">
          <div className="pointer-events-none absolute left-1/2 top-10 w-full -translate-x-1/2 text-center font-display text-[clamp(3.8rem,10vw,8.2rem)] uppercase leading-none tracking-[0.08em] text-transparent [text-shadow:none] [-webkit-text-stroke:1px_rgba(35,26,20,0.06)]">
            Popular Dishes • Popular Dishes
          </div>

          <div className="relative z-10 text-center">
            <p
              className="text-[11px] font-extrabold uppercase tracking-[0.35em] text-[var(--brand-red)]/70"
              data-reveal="fade-up"
              style={motionStyle(0)}
            >
              Your cravings, covered
            </p>

            <SplitReveal
              as="h2"
              className="mx-auto mt-4 block font-display text-[clamp(3.4rem,7vw,5.2rem)] uppercase leading-[0.9] tracking-[0.02em] text-[var(--ink)]"
              delay={100}
              text="Best Selling Dishes"
            />

            <p
              className="mx-auto mt-5 max-w-[30rem] text-[1.02rem] leading-8 text-[var(--ink-muted)]"
              data-reveal="fade-up"
              style={motionStyle(220, 700)}
            >
              Fresh favorites. Big flavors. Never a wrong choice.
            </p>
          </div>

          <div className="relative z-10 mt-14 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {dishes.map((dish, index) => (
              <article
                className="overflow-hidden rounded-[30px] border border-[rgba(35,26,20,0.08)] bg-white shadow-[0_24px_50px_rgba(95,74,44,0.08)]"
                data-reveal={index % 2 === 0 ? "lift" : "scale-blur"}
                key={dish.title}
                style={motionStyle(80 + index * 90, 760)}
              >
                <div className="dish-card h-full p-5">
                  <div className="flex items-center justify-between gap-3">
                    <span className="rounded-full bg-[var(--cream-strong)] px-3 py-1 text-[10px] font-bold uppercase tracking-[0.22em] text-[var(--ink-muted)]">
                      {dish.badge}
                    </span>
                    <button
                      aria-label={`Save ${dish.title}`}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[rgba(35,26,20,0.08)] text-[var(--ink-muted)] transition-all duration-300 hover:border-[var(--brand-red)] hover:text-[var(--brand-red)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-red)] focus-visible:ring-offset-2"
                      type="button"
                    >
                      <HeartIcon className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="mt-5">
                    {dish.tilt ? (
                      <TiltFrame>
                        <div className="overflow-hidden rounded-[24px] bg-[var(--cream-strong)] p-3">
                          <img
                            alt={dish.title}
                            className="aspect-square w-full rounded-[18px] object-cover"
                            decoding="async"
                            loading="lazy"
                            src={dish.image}
                          />
                        </div>
                      </TiltFrame>
                    ) : (
                      <div className="overflow-hidden rounded-[24px] bg-[var(--cream-strong)] p-3">
                        <img
                          alt={dish.title}
                          className="aspect-square w-full rounded-[18px] object-cover"
                          decoding="async"
                          loading="lazy"
                          src={dish.image}
                        />
                      </div>
                    )}
                  </div>

                  <div className="mt-5 flex items-center gap-2 text-xs text-[var(--ink-muted)]">
                    <div className="flex items-center gap-1 text-[var(--gold)]">
                      {Array.from({ length: 5 }).map((_, starIndex) => (
                        <span key={starIndex} className="rating-dot small" />
                      ))}
                    </div>
                    <span>{dish.rating}</span>
                  </div>

                  <h3 className="mt-4 font-display text-[2.05rem] uppercase leading-[0.9] tracking-[0.02em] text-[var(--ink)]">
                    {dish.title}
                  </h3>
                  <p className="mt-3 text-sm leading-7 text-[var(--ink-muted)]">{dish.description}</p>

                  <div className="mt-6 flex items-center justify-between gap-4">
                    <div className="font-display text-[2rem] uppercase leading-none tracking-[0.04em] text-[var(--brand-red)]">
                      {dish.price}
                    </div>
                    <button
                      aria-label={`Add ${dish.title}`}
                      className="inline-flex h-10 w-10 items-center justify-center rounded-[14px] bg-[var(--brand-green)] text-white transition-all duration-300 hover:translate-y-[-2px] hover:shadow-[0_14px_28px_rgba(39,109,76,0.26)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-green)] focus-visible:ring-offset-2"
                      type="button"
                    >
                      <PlusIcon className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <div className="relative z-10 mt-10 flex items-center justify-center gap-4" data-reveal="fade-up" style={motionStyle(420, 660)}>
            <button
              aria-label="Previous dishes"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[rgba(35,26,20,0.08)] bg-white text-[var(--ink-muted)] transition-colors duration-300 hover:border-[var(--brand-red)] hover:text-[var(--brand-red)]"
              type="button"
            >
              <ChevronLeftIcon className="h-4 w-4" />
            </button>
            <span className="inline-flex h-1.5 w-10 rounded-full bg-[var(--brand-green)]" />
            <button
              aria-label="Next dishes"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[rgba(35,26,20,0.08)] bg-white text-[var(--ink-muted)] transition-colors duration-300 hover:border-[var(--brand-red)] hover:text-[var(--brand-red)]"
              type="button"
            >
              <ChevronRightIcon className="h-4 w-4" />
            </button>
          </div>

          <div className="relative z-10 mt-10 text-center" data-reveal="fade-up" style={motionStyle(480, 720)}>
            <ActionButton href="#menu" variant="ghost">
              Explore the full menu
            </ActionButton>
          </div>
        </section>

        <section className="mx-auto w-full max-w-[1240px] px-4 pb-18 sm:px-6 lg:px-8 lg:pb-24">
          <div className="promo-hero relative overflow-hidden rounded-[34px]">
            <div className="grid items-center gap-6 lg:grid-cols-[0.78fr_1.22fr]">
              <div className="relative z-10 px-6 py-10 text-white sm:px-8 lg:px-12 lg:py-14">
                <p
                  className="text-[11px] font-extrabold uppercase tracking-[0.35em] text-[var(--gold-soft)]"
                  data-reveal="fade-up"
                  style={motionStyle(0)}
                >
                  Let&apos;s spice things up
                </p>

                <h2 className="mt-5 font-display text-[clamp(3.4rem,7vw,5.8rem)] uppercase leading-[0.86] tracking-[0.02em] text-white">
                  <span className="block overflow-hidden">
                    <span className="block" data-reveal="mask-up" style={motionStyle(120, 820)}>
                      Quesadilla
                    </span>
                  </span>
                  <span className="block overflow-hidden text-[var(--gold)]">
                    <span className="block" data-reveal="mask-up" style={motionStyle(220, 820)}>
                      With Tomatoes
                    </span>
                  </span>
                </h2>

                <p
                  className="mt-5 max-w-[28rem] text-[1.02rem] leading-8 text-white/82"
                  data-reveal="fade-up"
                  style={motionStyle(300)}
                >
                  Loaded on the outside. All the good stuff inside. Meet your new lunchtime
                  obsession.
                </p>

                <div className="mt-8 flex flex-wrap gap-4" data-reveal="fade-up" style={motionStyle(360, 720)}>
                  {[
                    ["03", "Days"],
                    ["16", "Hours"],
                    ["34", "Mins"],
                    ["44", "Secs"],
                  ].map(([value, label], index) => (
                    <div className="timer-cell" key={`${label}-${index}`}>
                      <div className="font-display text-[2.6rem] leading-none tracking-[0.04em]">
                        {value}
                      </div>
                      <div className="mt-1 text-[10px] font-bold uppercase tracking-[0.28em] text-white/64">
                        {label}
                      </div>
                    </div>
                  ))}
                </div>

                <div data-reveal="scale-blur" style={motionStyle(420, 760)}>
                  <ActionButton className="mt-8" href="#menu" variant="light">
                    Get your fix
                  </ActionButton>
                </div>

                <p
                  className="mt-5 text-sm text-white/65"
                  data-reveal="fade-up"
                  style={motionStyle(500, 700)}
                >
                  Ends limited-time promotion
                </p>
              </div>

              <div className="relative min-h-[300px] lg:min-h-[560px]">
                <div
                  className="absolute left-[2rem] top-[2rem] z-20 grid h-28 w-28 place-items-center rounded-full bg-[var(--gold)] text-[var(--ink)] shadow-[0_18px_40px_rgba(0,0,0,0.22)]"
                  data-reveal="pop"
                  style={motionStyle(200, 760)}
                >
                  <div className="text-center">
                    <div className="text-[12px] font-bold uppercase tracking-[0.24em] text-[var(--ink)]/70">
                      Only
                    </div>
                    <div className="font-display text-[1.3rem] uppercase tracking-[0.08em]">$8</div>
                    <div className="-mt-1 font-display text-[3.05rem] leading-none">.99</div>
                  </div>
                </div>

                <div className="absolute inset-0" data-reveal="fade-left" style={motionStyle(140, 940)}>
                  <img
                    alt="Grilled quesadilla with tomatoes"
                    className="h-full w-full object-cover object-center"
                    decoding="async"
                    loading="lazy"
                    src={images.quesadilla}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[rgba(35,26,20,0.08)] bg-white/85" id="contact">
          <div className="mx-auto grid w-full max-w-[1240px] gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[0.95fr_1.05fr] lg:px-8 lg:py-18">
            <div className="grid gap-6 sm:grid-cols-[auto_1fr] sm:items-center">
              <div data-reveal="fade-right" style={motionStyle(60, 860)}>
                <TiltFrame className="mx-auto w-[180px] sm:mx-0 sm:w-[220px]">
                  <div className="overflow-hidden rounded-[28px] bg-[var(--cream-strong)] p-3 shadow-[0_20px_44px_rgba(95,74,44,0.1)]">
                    <img
                      alt="Cold drink with ice"
                      className="aspect-[4/5] w-full rounded-[22px] object-cover"
                      decoding="async"
                      loading="lazy"
                      src={images.drink}
                    />
                  </div>
                </TiltFrame>
              </div>

              <div>
                <p
                  className="font-script text-[2rem] leading-none text-[var(--brand-red)]/80"
                  data-reveal="fade-up"
                  style={motionStyle(40, 700)}
                >
                  Good food, good people.
                </p>
                <h2
                  className="mt-3 font-display text-[clamp(3rem,7vw,5rem)] uppercase leading-[0.88] tracking-[0.02em] text-[var(--ink)]"
                  data-reveal="fade-up"
                  style={motionStyle(140, 820)}
                >
                  Flame &amp; Bun
                </h2>
                <p
                  className="mt-4 max-w-[28rem] text-[1.02rem] leading-8 text-[var(--ink-muted)]"
                  data-reveal="fade-up"
                  style={motionStyle(220, 740)}
                >
                  Freshly made. Full of flavor.
                </p>
              </div>
            </div>

            <div className="flex flex-col justify-center gap-8 lg:items-end">
              <ul
                className="flex flex-wrap gap-x-6 gap-y-3"
                data-reveal="lift"
                style={motionStyle(180, 700)}
              >
                {footerLinks.map((link) => (
                  <li key={link.label}>
                    <a
                      className="text-sm font-semibold uppercase tracking-[0.14em] text-[var(--ink-muted)] transition-colors duration-300 hover:text-[var(--brand-red)]"
                      href={link.href}
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>

              <p
                className="max-w-[28rem] text-sm leading-7 text-[var(--ink-muted)] lg:text-right"
                data-reveal="fade-up"
                style={motionStyle(260, 700)}
              >
                Free delivery on orders over $35 / Use FLAME10 for 10% off
              </p>

              <div data-reveal="scale-blur" style={motionStyle(340, 760)}>
                <ActionButton href="#popular">Order now</ActionButton>
              </div>
            </div>
          </div>
      </footer>
    </div>
  );
}

function IconButton({
  children,
  ariaLabel,
}: {
  children: ReactNode;
  ariaLabel: string;
}) {
  return (
    <button
      aria-label={ariaLabel}
      className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[rgba(35,26,20,0.08)] bg-white text-[var(--ink)] transition-all duration-300 hover:translate-y-[-2px] hover:border-[var(--brand-red)] hover:text-[var(--brand-red)] hover:shadow-[0_14px_28px_rgba(96,68,42,0.14)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-red)] focus-visible:ring-offset-2"
      type="button"
    >
      {children}
    </button>
  );
}

function LogoMark() {
  return (
    <div className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-[rgba(196,82,56,0.08)] text-[var(--brand-red)]">
      <svg aria-hidden="true" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12.58 2.25c.48 2.88 2.42 4.4 4.08 6.19 1.74 1.87 3.12 3.83 3.12 6.71A7.78 7.78 0 0 1 12 22.93a7.78 7.78 0 0 1-7.78-7.78c0-4.07 2.84-6.62 5.71-9.66l1.47-1.56.29 2.12c.17 1.29.64 2.19 1.27 3.02.41-1.41.14-3.05-.52-5.17l-.26-.82.4-.83Z" />
      </svg>
    </div>
  );
}

function SearchIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.8" />
      <path d="M16 16l4 4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
    </svg>
  );
}

function CartIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <path d="M3.5 5h2.3l2.2 9.4a1 1 0 0 0 1 .77h7.8a1 1 0 0 0 .97-.76L20.2 8H7.2" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
      <circle cx="10.2" cy="19" r="1.1" fill="currentColor" />
      <circle cx="17.6" cy="19" r="1.1" fill="currentColor" />
    </svg>
  );
}

function LeafSparkIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <path d="M18.5 5.5c-5.32.3-9.13 2.47-11.5 7.5 3.37-1.95 6.14-2.72 9.5-2.5-1.55 2.7-3.83 4.4-7 5.2" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
      <path d="M7.5 18.5c1.1-2.4 3.08-4.32 5.5-5.5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
    </svg>
  );
}

function FlameIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <path d="M13.4 3.3c.92 2.03.64 4.35-.85 6.95 2.35-.55 3.92.4 4.72 2.84.9 2.7-.38 5.96-4.27 7.15-3.7-1.08-5.32-4.37-4.44-7.28.55-1.81 1.73-3.22 3.51-4.22-.2 1.42-.07 2.5.39 3.25 1.18-2.11 1.5-4.38.94-6.8Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
    </svg>
  );
}

function ScooterIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <circle cx="7" cy="17" r="2.5" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="18" cy="17" r="2.5" stroke="currentColor" strokeWidth="1.8" />
      <path d="M9.5 17h5.5l2.5-5.5H11l-1.3-2H7.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
      <path d="M15.8 8.2H19v2.2" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
    </svg>
  );
}

function HeartIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <path d="M12 20.25 4.8 13.3a4.55 4.55 0 0 1 0-6.55 4.88 4.88 0 0 1 6.78 0L12 7.17l.42-.42a4.88 4.88 0 0 1 6.78 0 4.55 4.55 0 0 1 0 6.55L12 20.25Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
    </svg>
  );
}

function PlusIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <path d="M12 5v14M5 12h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
    </svg>
  );
}

function ChevronLeftIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <path d="m14.5 6.5-5 5 5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
    </svg>
  );
}

function ChevronRightIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <path d="m9.5 6.5 5 5-5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
    </svg>
  );
}

function ArrowUpRightIcon({ className }: { className?: string }) {
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24">
      <path d="M7 17 17 7M9.5 7H17v7.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
    </svg>
  );
}

export default App;
